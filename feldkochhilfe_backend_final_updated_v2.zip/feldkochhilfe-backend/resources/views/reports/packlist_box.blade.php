<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Packliste Box</title>
    <style>
        body { font-family: sans-serif; font-size: 12px; color: #333; }
        h1 { font-size: 20px; margin-bottom: 10px; }
        p { margin: 4px 0; }
    </style>
</head>
<body>
    <h1>Packliste für Box: {{ $box->name }}</h1>
    @if($box->deployment)
    <p><strong>Einsatz:</strong> {{ $box->deployment->name }}</p>
    @endif
    @if($box->description)
    <p><strong>Beschreibung:</strong> {{ $box->description }}</p>
    @endif
    @if($box->capacity)
    <p><strong>Kapazität:</strong> {{ $box->capacity }}</p>
    @endif
</body>
</html>