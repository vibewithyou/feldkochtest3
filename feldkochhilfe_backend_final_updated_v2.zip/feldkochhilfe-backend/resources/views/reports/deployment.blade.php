<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Einsatzbericht</title>
    <style>
        body { font-family: sans-serif; font-size: 12px; color: #333; }
        h1 { font-size: 20px; margin-bottom: 10px; }
        h2 { font-size: 16px; margin-top: 20px; margin-bottom: 5px; }
        table { width: 100%; border-collapse: collapse; margin-top: 5px; }
        th, td { border: 1px solid #ccc; padding: 4px; text-align: left; }
        th { background-color: #f0f0f0; }
    </style>
</head>
<body>
    <h1>Einsatz: {{ $deployment->name }}</h1>
    @if($deployment->date)
    <p><strong>Datum:</strong> {{ $deployment->date }}</p>
    @endif
    @if($deployment->location)
    <p><strong>Ort:</strong> {{ $deployment->location }}</p>
    @endif
    @if($deployment->notes)
    <p><strong>Notizen:</strong> {{ $deployment->notes }}</p>
    @endif

    <h2>Kisten</h2>
    <table>
        <thead>
            <tr><th>Name</th><th>Beschreibung</th><th>Kapazität</th></tr>
        </thead>
        <tbody>
        @foreach($deployment->boxes as $box)
            <tr>
                <td>{{ $box->name }}</td>
                <td>{{ $box->description }}</td>
                <td>{{ $box->capacity }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
</body>
</html>