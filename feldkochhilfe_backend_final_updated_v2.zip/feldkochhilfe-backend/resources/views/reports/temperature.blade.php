<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Temperaturmessungen</title>
    <style>
        body { font-family: sans-serif; font-size: 12px; color: #333; }
        h1 { font-size: 20px; margin-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 5px; }
        th, td { border: 1px solid #ccc; padding: 4px; text-align: left; }
        th { background-color: #f0f0f0; }
    </style>
</head>
<body>
    <h1>Temperaturmessungen</h1>
    <table>
        <thead>
            <tr><th>Kiste</th><th>Temperatur (°C)</th><th>gemessen am</th></tr>
        </thead>
        <tbody>
        @foreach($measurements as $m)
            <tr>
                <td>{{ optional($m->box)->name }}</td>
                <td>{{ $m->temperature }}</td>
                <td>{{ $m->measured_at }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
</body>
</html>