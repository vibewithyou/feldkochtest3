<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Rezeptbericht</title>
    <style>
        body { font-family: sans-serif; font-size: 12px; color: #333; }
        h1 { font-size: 20px; margin-bottom: 10px; }
        h2 { font-size: 16px; margin-top: 20px; margin-bottom: 5px; }
        table { width: 100%; border-collapse: collapse; margin-top: 5px; }
        th, td { border: 1px solid #ccc; padding: 4px; text-align: left; }
        th { background-color: #f0f0f0; }
    </style>
</head>
<body>
    <h1>Rezept: {{ $recipe->name }}</h1>
    <p><strong>Portionen:</strong> {{ $recipe->portion_count }}</p>
    @if($recipe->description)
    <p>{{ $recipe->description }}</p>
    @endif

    <h2>Zutaten</h2>
    <table>
        <thead>
            <tr><th>Name</th><th>Menge</th><th>Einheit</th></tr>
        </thead>
        <tbody>
        @foreach($recipe->ingredients as $ingredient)
            <tr>
                <td>{{ $ingredient->name }}</td>
                <td>{{ $ingredient->pivot->quantity }}</td>
                <td>{{ $ingredient->pivot->unit }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>

    @if($recipe->instructions)
    <h2>Anleitung</h2>
    <p>{!! nl2br(e($recipe->instructions)) !!}</p>
    @endif
</body>
</html>