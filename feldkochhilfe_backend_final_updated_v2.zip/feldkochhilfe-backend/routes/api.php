<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\RecipeController;
use App\Http\Controllers\IngredientsController;
use App\Http\Controllers\BoxController;
use App\Http\Controllers\DeploymentController;
use App\Http\Controllers\TemperatureMeasurementController;
use App\Http\Controllers\ShoppingListController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ReportController;

// API-Routen, die Sanctum-Authentifizierung erfordern
Route::middleware('auth:sanctum')->group(function () {
    // CRUD-Ressourcen
    Route::apiResource('products', ProductController::class);
    Route::apiResource('recipes', RecipeController::class);
    Route::apiResource('ingredients', IngredientsController::class);
    Route::apiResource('boxes', BoxController::class);
    Route::apiResource('deployments', DeploymentController::class);
    Route::apiResource('temperatures', TemperatureMeasurementController::class)->only(['index','store']);
    Route::apiResource('shopping-lists', ShoppingListController::class);

    // Zusätzliche Endpoints
    Route::get('/products/{product}/qr', [ProductController::class, 'showQr']);
    Route::get('/products/{product}/barcode', [ProductController::class, 'showBarcode']);
    Route::get('/deployments/{deployment}/packlist', [DeploymentController::class, 'exportPacklist']);

    // Benutzerverwaltung
    Route::apiResource('users', UserController::class);
    Route::get('/me', [UserController::class, 'me']);
    Route::put('/me', [UserController::class, 'updateMe']);
    Route::post('/users/{user}/roles', [UserController::class, 'updateRole']);
    Route::get('/roles', [UserController::class, 'roles']);

    // Bericht‑Endpoints
    Route::get('/reports/recipes/{recipe}', [ReportController::class, 'recipe']);
    Route::get('/reports/deployments/{deployment}', [ReportController::class, 'deployment']);
    Route::get('/reports/packlist', [ReportController::class, 'packList']);
    Route::get('/reports/temperature', [ReportController::class, 'temperature']);
});

// Öffentliche Route für die Anmeldung (Token-Ausgabe)
Route::post('/login', [AuthController::class, 'login']);

