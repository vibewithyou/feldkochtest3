<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Ingredient;
use Illuminate\Http\Request;

class IngredientsController extends Controller
{
    public function index()
    {
        return response()->json(Ingredient::paginate());
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'unit' => 'nullable|string|max:50',
            'cost' => 'nullable|numeric',
        ]);

        $ingredient = Ingredient::create($data);
        return response()->json($ingredient, 201);
    }

    public function show(Ingredient $ingredients)
    {
        // Achtung: Route-Model-Binding nutzt hier den Plural-Parameter "ingredients"
        return response()->json($ingredients);
    }

    public function update(Request $request, Ingredient $ingredients)
    {
        $data = $request->validate([
            'name' => 'sometimes|string|max:255',
            'unit' => 'nullable|string|max:50',
            'cost' => 'nullable|numeric',
        ]);

        $ingredients->update($data);
        return response()->json($ingredients);
    }

    public function destroy(Ingredient $ingredients)
    {
        $ingredients->delete();
        return response()->noContent();
    }
}

