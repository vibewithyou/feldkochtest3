<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Deployment;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

class DeploymentController extends Controller
{
    public function index()
    {
        return response()->json(Deployment::with('boxes')->paginate());
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'date' => 'nullable|date',
            'location' => 'nullable|string',
            'notes' => 'nullable|string',
        ]);

        $deployment = Deployment::create($data);
        return response()->json($deployment, 201);
    }

    public function show(Deployment $deployment)
    {
        return response()->json($deployment->load('boxes'));
    }

    public function update(Request $request, Deployment $deployment)
    {
        $data = $request->validate([
            'name' => 'sometimes|string|max:255',
            'date' => 'nullable|date',
            'location' => 'nullable|string',
            'notes' => 'nullable|string',
        ]);

        $deployment->update($data);
        return response()->json($deployment);
    }

    public function destroy(Deployment $deployment)
    {
        $deployment->delete();
        return response()->noContent();
    }

    public function exportPacklist(Deployment $deployment)
    {
        $pdf = Pdf::loadView('reports.packlist', ['deployment' => $deployment->load('boxes')]);
        return $pdf->download('packliste_'.$deployment->id.'.pdf');
    }
}

