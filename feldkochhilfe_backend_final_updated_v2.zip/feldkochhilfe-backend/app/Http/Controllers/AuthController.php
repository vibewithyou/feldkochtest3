<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

/**
 * Class AuthController
 *
 * Bietet Endpunkte für die Benutzeranmeldung über E‑Mail und Passwort,
 * Rückgabe des aktuellen Benutzers und Logout.
 * Die Token‑Erstellung basiert auf Laravel Sanctum.
 */
class AuthController extends Controller
{
    /**
     * Anmeldung und Ausgabe eines API‑Tokens.
     */
    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        $user = User::where('email', $credentials['email'])->first();
        if (!$user || !Hash::check($credentials['password'], $user->password)) {
            return response()->json(['message' => 'Invalid credentials'], 401);
        }
        // Lösche vorhandene Tokens optional, wenn nur ein Token zulässig sein soll
        // $user->tokens()->delete();
        $token = $user->createToken('api-token')->plainTextToken;
        return response()->json([
            'user' => $user->load('roles'),
            'token' => $token,
        ]);
    }

    /**
     * Aktuellen Benutzer zurückgeben.
     */
    public function me(Request $request)
    {
        return response()->json($request->user()->load('roles'));
    }

    /**
     * Logout: Das aktuelle Token widerrufen.
     */
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json(['message' => 'Logged out']);
    }
}