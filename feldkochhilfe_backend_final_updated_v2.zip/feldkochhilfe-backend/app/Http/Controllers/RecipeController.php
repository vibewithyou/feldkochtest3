<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Recipe;
use Illuminate\Http\Request;

class RecipeController extends Controller
{
    public function index()
    {
        $query = Recipe::query();
        if ($search = request('search')) {
            $query = Recipe::search($search);
        }
        return response()->json($query->paginate());
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'portion_count' => 'required|integer|min:1',
            'instructions' => 'nullable|string',
            'cost' => 'nullable|numeric',
            'ingredients' => 'nullable|array',
        ]);

        $recipe = Recipe::create($data);

        foreach ($request->input('ingredients', []) as $item) {
            $recipe->ingredients()->attach($item['id'], [
                'quantity' => $item['quantity'],
                'unit' => $item['unit'] ?? null,
            ]);
        }

        return response()->json($recipe->load('ingredients'), 201);
    }

    public function show(Recipe $recipe)
    {
        return response()->json($recipe->load('ingredients'));
    }

    public function update(Request $request, Recipe $recipe)
    {
        $data = $request->validate([
            'name' => 'sometimes|string|max:255',
            'description' => 'nullable|string',
            'portion_count' => 'sometimes|integer|min:1',
            'instructions' => 'nullable|string',
            'cost' => 'nullable|numeric',
            'ingredients' => 'nullable|array',
        ]);

        $recipe->update($data);

        if ($request->has('ingredients')) {
            $sync = [];
            foreach ($request->input('ingredients', []) as $item) {
                $sync[$item['id']] = [
                    'quantity' => $item['quantity'],
                    'unit' => $item['unit'] ?? null,
                ];
            }
            $recipe->ingredients()->sync($sync);
        }

        return response()->json($recipe->load('ingredients'));
    }

    public function destroy(Recipe $recipe)
    {
        $recipe->delete();
        return response()->noContent();
    }
}

