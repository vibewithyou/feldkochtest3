<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Milon\Barcode\DNS1D;

class ProductController extends Controller
{
    public function index()
    {
        $query = Product::query();
        if ($search = request('search')) {
            // Nutze MeiliSearch, falls das Searchable-Trait verwendet wird
            $query = Product::search($search);
        }
        return response()->json($query->paginate());
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'unit' => 'nullable|string|max:50',
            'cost' => 'nullable|numeric',
            'sku' => 'nullable|string|max:100|unique:products,sku',
            'barcode' => 'nullable|string|max:100|unique:products,barcode',
            'expiration_date' => 'nullable|date',
            'tags' => 'nullable|array',
        ]);

        $product = Product::create($data);

        if (!empty($data['tags'])) {
            $product->attachTags($data['tags']);
        }

        return response()->json($product, 201);
    }

    public function show(Product $product)
    {
        return response()->json($product);
    }

    public function update(Request $request, Product $product)
    {
        $data = $request->validate([
            'name' => 'sometimes|string|max:255',
            'description' => 'nullable|string',
            'unit' => 'nullable|string|max:50',
            'cost' => 'nullable|numeric',
            'sku' => 'nullable|string|max:100|unique:products,sku,' . $product->id,
            'barcode' => 'nullable|string|max:100|unique:products,barcode,' . $product->id,
            'expiration_date' => 'nullable|date',
            'tags' => 'nullable|array',
        ]);

        $product->update($data);

        if (array_key_exists('tags', $data)) {
            $product->syncTags($data['tags'] ?? []);
        }

        return response()->json($product);
    }

    public function destroy(Product $product)
    {
        $product->delete();
        return response()->noContent();
    }

    public function showQr(Product $product)
    {
        // QR-Code basierend auf der Produkt-ID erzeugen
        $svg = QrCode::size(200)->generate((string) $product->id);
        return response($svg, 200)->header('Content-Type', 'image/svg+xml');
    }

    public function showBarcode(Product $product)
    {
        if (!$product->barcode) {
            return response()->json(['message' => 'No barcode set'], 404);
        }
        $svg = DNS1D::getBarcodeSVG($product->barcode, 'C39');
        return response($svg, 200)->header('Content-Type', 'image/svg+xml');
    }
}

