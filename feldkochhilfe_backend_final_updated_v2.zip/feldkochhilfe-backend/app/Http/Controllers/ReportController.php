<?php

namespace App\Http\Controllers;

use App\Models\Recipe;
use App\Models\Deployment;
use App\Models\TemperatureMeasurement;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

/**
 * Class ReportController
 *
 * Dieser Controller erzeugt PDF‑Berichte für Rezepte, Einsätze, Packlisten
 * und Temperaturmessungen. Die PDF‑Generierung basiert auf Blade‑Vorlagen
 * im Verzeichnis resources/views/reports. Für Excel‑Exporte könnte das
 * Paket maatwebsite/excel verwendet werden.
 */
class ReportController extends Controller
{
    /**
     * PDF‑Bericht für ein Rezept erzeugen.
     */
    public function recipe(int $recipeId)
    {
        $recipe = Recipe::with('ingredients')->findOrFail($recipeId);
        $pdf = Pdf::loadView('reports.recipe', [
            'recipe' => $recipe,
        ]);
        return $pdf->download('recipe_'.$recipe->id.'.pdf');
    }

    /**
     * PDF‑Bericht für einen Einsatz inkl. zugehöriger Boxen erzeugen.
     */
    public function deployment(int $deploymentId)
    {
        $deployment = Deployment::with('boxes')->findOrFail($deploymentId);
        $pdf = Pdf::loadView('reports.deployment', [
            'deployment' => $deployment,
        ]);
        return $pdf->download('deployment_'.$deployment->id.'.pdf');
    }

    /**
     * Packliste für einen Einsatz oder eine Kiste als PDF exportieren.
     * Erwartet im Request entweder einen deployment_id oder box_id.
     */
    public function packList(Request $request)
    {
        $request->validate([
            'deployment_id' => 'nullable|exists:deployments,id',
            'box_id' => 'nullable|exists:boxes,id',
        ]);

        if ($request->filled('deployment_id')) {
            $deployment = Deployment::with('boxes')->findOrFail($request->deployment_id);
            $pdf = Pdf::loadView('reports.packlist', ['deployment' => $deployment]);
            return $pdf->download('packlist_deployment_'.$deployment->id.'.pdf');
        }
        if ($request->filled('box_id')) {
            $box = \App\Models\Box::with('deployment')->findOrFail($request->box_id);
            $pdf = Pdf::loadView('reports.packlist_box', ['box' => $box]);
            return $pdf->download('packlist_box_'.$box->id.'.pdf');
        }
        return response()->json(['message' => 'Bitte deployment_id oder box_id angeben'], 400);
    }

    /**
     * Temperaturmessungen als PDF exportieren.
     */
    public function temperature()
    {
        $measurements = TemperatureMeasurement::with('box')->orderByDesc('measured_at')->get();
        $pdf = Pdf::loadView('reports.temperature', [
            'measurements' => $measurements,
        ]);
        return $pdf->download('temperature_measurements.pdf');
    }
}