<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\ShoppingList;
use Illuminate\Http\Request;

class ShoppingListController extends Controller
{
    public function index()
    {
        return response()->json(
            ShoppingList::with('items.product')->paginate()
        );
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'notes' => 'nullable|string',
            'items' => 'nullable|array',
        ]);

        $list = ShoppingList::create($data);

        foreach ($request->input('items', []) as $item) {
            $list->items()->create([
                'product_id' => $item['product_id'],
                'quantity' => $item['quantity'] ?? 1,
                'unit' => $item['unit'] ?? null,
            ]);
        }

        return response()->json($list->load('items.product'), 201);
    }

    public function show(ShoppingList $shoppingList)
    {
        return response()->json($shoppingList->load('items.product'));
    }

    public function update(Request $request, ShoppingList $shoppingList)
    {
        $data = $request->validate([
            'name' => 'sometimes|string|max:255',
            'notes' => 'nullable|string',
            'items' => 'nullable|array',
        ]);

        $shoppingList->update($data);

        if ($request->has('items')) {
            $shoppingList->items()->delete();
            foreach ($request->input('items', []) as $item) {
                $shoppingList->items()->create([
                    'product_id' => $item['product_id'],
                    'quantity' => $item['quantity'] ?? 1,
                    'unit' => $item['unit'] ?? null,
                ]);
            }
        }

        return response()->json($shoppingList->load('items.product'));
    }

    public function destroy(ShoppingList $shoppingList)
    {
        $shoppingList->delete();
        return response()->noContent();
    }
}

