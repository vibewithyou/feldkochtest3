<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

/**
 * Class UserController
 *
 * Dieser Controller verwaltet Benutzer und ihre Rollen. Er bietet CRUD‑Operationen
 * für Benutzer, eine Möglichkeit, die Rolle eines Benutzers zu ändern,
 * sowie Endpunkte, um den eigenen Benutzer abzurufen und zu aktualisieren.
 */
class UserController extends Controller
{
    /**
     * Liste aller Benutzer mit ihren Rollen.
     */
    public function index()
    {
        // Lade alle Benutzer und ihre Rollen
        $users = User::with('roles')->paginate();
        return response()->json($users);
    }

    /**
     * Einen bestimmten Benutzer anzeigen.
     */
    public function show(User $user)
    {
        return response()->json($user->load('roles'));
    }

    /**
     * Neuen Benutzer erstellen.
     * Erwartet name, email, password und optional role.
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email',
            'password' => 'required|string|min:6',
            'role' => 'nullable|string',
        ]);

        $user = new User();
        $user->name = $data['name'];
        $user->email = $data['email'];
        $user->password = Hash::make($data['password']);
        $user->save();

        // Optional Rolle zuweisen
        if (!empty($data['role'])) {
            $role = Role::firstOrCreate(['name' => $data['role']]);
            $user->assignRole($role);
        }

        return response()->json($user->load('roles'), 201);
    }

    /**
     * Benutzer aktualisieren.
     */
    public function update(Request $request, User $user)
    {
        $data = $request->validate([
            'name' => 'sometimes|string|max:255',
            'email' => ['sometimes','string','email','max:255', Rule::unique('users','email')->ignore($user->id)],
            'password' => 'nullable|string|min:6',
        ]);

        $user->fill($data);
        if (!empty($data['password'])) {
            $user->password = Hash::make($data['password']);
        }
        $user->save();

        return response()->json($user->load('roles'));
    }

    /**
     * Benutzer löschen.
     */
    public function destroy(User $user)
    {
        $user->delete();
        return response()->noContent();
    }

    /**
     * Rolle eines Benutzers aktualisieren.
     */
    public function updateRole(Request $request, User $user)
    {
        $request->validate([
            'role' => 'required|string',
        ]);

        $roleName = $request->input('role');
        $role = Role::firstOrCreate(['name' => $roleName]);

        // Rolle zuweisen und andere Rollen entfernen
        $user->syncRoles([$role]);
        return response()->json($user->load('roles'));
    }

    /**
     * Aktuellen authentifizierten Benutzer abrufen.
     */
    public function me(Request $request)
    {
        return response()->json($request->user()->load('roles'));
    }

    /**
     * Profil des aktuellen Benutzers aktualisieren.
     */
    public function updateMe(Request $request)
    {
        $user = $request->user();
        $data = $request->validate([
            'name' => 'sometimes|string|max:255',
            'email' => ['sometimes','string','email','max:255', Rule::unique('users','email')->ignore($user->id)],
            'password' => 'nullable|string|min:6',
        ]);
        $user->fill($data);
        if (!empty($data['password'])) {
            $user->password = Hash::make($data['password']);
        }
        $user->save();
        return response()->json($user->load('roles'));
    }

    /**
     * Alle verfügbaren Rollen auflisten.
     */
    public function roles()
    {
        $roles = Role::all()->pluck('name');
        return response()->json($roles);
    }
}