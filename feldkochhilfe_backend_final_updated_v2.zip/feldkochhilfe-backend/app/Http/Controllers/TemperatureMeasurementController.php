<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\TemperatureMeasurement;
use Illuminate\Http\Request;

class TemperatureMeasurementController extends Controller
{
    public function index()
    {
        return response()->json(
            TemperatureMeasurement::with('box')
                ->orderByDesc('measured_at')
                ->paginate()
        );
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'box_id' => 'nullable|exists:boxes,id',
            'temperature' => 'required|numeric',
            'measured_at' => 'nullable|date',
            'user_id' => 'nullable|exists:users,id',
        ]);

        $measurement = TemperatureMeasurement::create($data);
        return response()->json($measurement, 201);
    }
}

