<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Box;
use Illuminate\Http\Request;

class BoxController extends Controller
{
    public function index()
    {
        return response()->json(Box::with('deployment')->paginate());
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'deployment_id' => 'nullable|exists:deployments,id',
            'location_id' => 'nullable|integer',
            'capacity' => 'nullable|integer',
        ]);

        $box = Box::create($data);
        return response()->json($box, 201);
    }

    public function show(Box $box)
    {
        return response()->json($box->load('deployment'));
    }

    public function update(Request $request, Box $box)
    {
        $data = $request->validate([
            'name' => 'sometimes|string|max:255',
            'description' => 'nullable|string',
            'deployment_id' => 'nullable|exists:deployments,id',
            'location_id' => 'nullable|integer',
            'capacity' => 'nullable|integer',
        ]);

        $box->update($data);
        return response()->json($box);
    }

    public function destroy(Box $box)
    {
        $box->delete();
        return response()->noContent();
    }
}

