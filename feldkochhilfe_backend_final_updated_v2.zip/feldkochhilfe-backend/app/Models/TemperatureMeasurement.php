<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TemperatureMeasurement extends Model
{
    protected $fillable = ['box_id', 'temperature', 'measured_at', 'user_id'];

    public function box()
    {
        return $this->belongsTo(Box::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}

