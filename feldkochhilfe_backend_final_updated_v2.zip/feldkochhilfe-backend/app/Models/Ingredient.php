<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Model Ingredient
 *
 * Repräsentiert eine einzelne Zutat. Rezepte bestehen aus vielen Zutaten,
 * und diese sind über die Pivot‑Tabelle recipe_ingredient verbunden.
 */
class Ingredient extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'name',
        'unit',
        'cost',
    ];

    public function recipes()
    {
        return $this->belongsToMany(Recipe::class)
                    ->withPivot('quantity', 'unit')
                    ->withTimestamps();
    }
}