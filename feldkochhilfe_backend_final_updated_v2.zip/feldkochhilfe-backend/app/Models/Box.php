<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Box extends Model
{
    use SoftDeletes;

    protected $fillable = ['name', 'description', 'deployment_id', 'location_id', 'capacity'];

    public function deployment()
    {
        return $this->belongsTo(Deployment::class);
    }

    public function temperatureMeasurements()
    {
        return $this->hasMany(TemperatureMeasurement::class);
    }
}

