<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShoppingList extends Model
{
    protected $fillable = ['name', 'notes'];

    public function items()
    {
        return $this->hasMany(ShoppingListItem::class);
    }
}

class ShoppingListItem extends Model
{
    protected $fillable = ['shopping_list_id', 'product_id', 'quantity', 'unit'];

    public function shoppingList()
    {
        return $this->belongsTo(ShoppingList::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }
}

