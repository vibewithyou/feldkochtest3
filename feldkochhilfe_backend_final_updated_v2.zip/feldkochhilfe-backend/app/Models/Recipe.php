<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Laravel\Scout\Searchable;

class Recipe extends Model
{
    use SoftDeletes, Searchable;

    protected $fillable = [
        'name',
        'description',
        'portion_count',
        'instructions',
        'cost',
    ];

    // Pivot-Verknüpfung zu Zutaten
    public function ingredients()
    {
        return $this->belongsToMany(Ingredient::class)
                    ->withPivot('quantity', 'unit')
                    ->withTimestamps();
    }

    // Berechne den Preis pro Portion
    public function getCostPerPortionAttribute(): ?float
    {
        return $this->portion_count ? round($this->cost / $this->portion_count, 2) : null;
    }

    // Suchbare Felder für Scout / MeiliSearch
    public function toSearchableArray(): array
    {
        return [
            'name' => $this->name,
            'description' => $this->description,
        ];
    }
}

