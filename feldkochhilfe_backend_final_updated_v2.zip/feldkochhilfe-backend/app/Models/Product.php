<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Tags\HasTags;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

class Product extends Model implements HasMedia
{
    use SoftDeletes, HasTags, InteractsWithMedia;

    protected $fillable = [
        'name',
        'description',
        'unit',
        'cost',
        'sku',
        'barcode',
        'expiration_date',
    ];

    // Beispielbeziehung: Ein Produkt kann in vielen Einkaufsliste-Positionen vorkommen
    public function shoppingListItems()
    {
        return $this->hasMany(ShoppingListItem::class);
    }
}

