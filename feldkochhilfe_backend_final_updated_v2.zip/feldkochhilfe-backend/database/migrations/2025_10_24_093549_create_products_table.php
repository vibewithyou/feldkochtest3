<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('name');                 // Produktname
            $table->text('description')->nullable();
            $table->string('unit')->nullable();     // Einheit (kg, l, Stück …)
            $table->decimal('cost', 10, 2)->nullable(); // Stückpreis
            $table->string('sku')->nullable()->unique(); // Artikelnummer
            $table->string('barcode')->nullable();       // Barcode für Scanner
            $table->date('expiration_date')->nullable(); // MHD
            $table->timestamps();
            $table->softDeletes(); // fügt deleted_at hinzu für SoftDeletes
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};

