<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTemperatureMeasurementsTable extends Migration
{
    public function up(): void
    {
        Schema::create('temperature_measurements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('box_id')->nullable()->constrained('boxes')->cascadeOnDelete();
            $table->decimal('temperature', 5, 2);
            $table->timestamp('measured_at')->useCurrent();
            $table->foreignId('user_id')->nullable()->constrained()->cascadeOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('temperature_measurements');
    }
}
